import csv
import io
import json
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from tjc import analytics, checklist, importer, reports, sample
from tjc.service import JourneyService, NotFound
from tjc.storage import Storage
from tjc.validators import ValidationError, build_item_fields, build_journey_fields, parse_date

TODAY = date(2026, 11, 25)


def raw(**over):
    base = {"passenger_name": "Asha Rao", "train_name": "Rajdhani Express", "train_number": "12951",
            "from_station": "Mumbai Central", "to_station": "New Delhi",
            "travel_date": (TODAY + timedelta(days=10)).isoformat(), "departure_time": "06:30",
            "coach_class": "2A", "passengers": "2"}
    base.update(over)
    return base


def make_service(tmp):
    return JourneyService(Storage(tmp), today_fn=lambda: TODAY)


class ValidatorTests(unittest.TestCase):
    def bad(self, **over):
        with self.assertRaises(ValidationError) as ctx:
            build_journey_fields(raw(**over), TODAY)
        return ctx.exception.errors

    def test_valid_record_is_cleaned(self):
        out = build_journey_fields(raw(passenger_name="  asha   rao ", train_name="rajdhani express"), TODAY)
        self.assertEqual(out["passenger_name"], "Asha Rao")
        self.assertEqual(out["passengers"], 2)

    def test_each_field_rejects_bad_input(self):
        cases = {"passenger_name": ["", "A", "R2D2", "x" * 41], "train_number": ["1234", "123456", "12A45", ""],
                 "departure_time": ["24:00", "6:30", "12:60", "noon"], "coach_class": ["XX", ""],
                 "passengers": ["0", "7", "two", "1.5"], "travel_date": ["31-02-2026", "tomorrow", ""],
                 "from_station": ["", "X", "St@tion"]}
        for field, values in cases.items():
            for value in values:
                self.assertIn(field, self.bad(**{field: value}), "%s=%r should be rejected" % (field, value))

    def test_date_range_and_formats(self):
        self.assertIn("travel_date", self.bad(travel_date=(TODAY - timedelta(days=366)).isoformat()))
        self.assertIn("travel_date", self.bad(travel_date=(TODAY + timedelta(days=366)).isoformat()))
        build_journey_fields(raw(travel_date=(TODAY - timedelta(days=365)).isoformat()), TODAY)   # boundary ok
        self.assertEqual(parse_date("31/12/2026"), date(2026, 12, 31))

    def test_same_station_rejected(self):
        self.assertIn("to_station", self.bad(to_station="mumbai central"))

    def test_all_errors_reported_together(self):
        self.assertGreaterEqual(len(self.bad(passenger_name="", train_number="x", passengers="9")), 3)

    def test_item_fields(self):
        self.assertEqual(build_item_fields({"name": "camera"}), {"name": "Camera", "category": "Other", "quantity": 1, "essential": False})
        for bad in ({"name": ""}, {"name": "x"}, {"name": "Ok", "quantity": "0"}, {"name": "Ok", "category": "Cars"}):
            with self.assertRaises(ValidationError):
                build_item_fields(bad)


class ChecklistTests(unittest.TestCase):
    def test_progress_maths(self):
        items = checklist.default_items()
        self.assertEqual(len(items), 14)
        self.assertEqual(checklist.completion(items), 0.0)
        self.assertEqual(checklist.readiness(items), "Not started")
        for item in items[:7]:
            item["packed"] = True
        self.assertEqual(checklist.completion(items), 50.0)
        self.assertEqual(checklist.readiness(items), "In progress")
        for item in items:
            item["packed"] = True
        self.assertEqual(checklist.readiness(items), "Ready")
        self.assertEqual(checklist.completion([]), 0.0)
        self.assertEqual(checklist.readiness([]), "Empty list")

    def test_essentials_and_trip_status(self):
        items = checklist.default_items()
        self.assertIn("Train ticket", checklist.essentials_missing(items))
        past = {"travel_date": "2026-11-24"}; today = {"travel_date": "2026-11-25"}; later = {"travel_date": "2026-11-26"}
        self.assertEqual([checklist.trip_status(j, TODAY) for j in (past, today, later)], ["Past", "Today", "Upcoming"])


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.svc = make_service(self._tmp.name)

    def test_crud_and_ids(self):
        a = self.svc.create(raw())
        b = self.svc.create(raw(passenger_name="Ravi Kumar"))
        self.assertEqual((a["id"], b["id"]), ("J0001", "J0002"))
        self.assertEqual(a["total_items"], 14)
        self.svc.update("J0001", raw(passenger_name="Asha Rao", to_station="Jaipur"))
        self.assertEqual(self.svc.get("J0001")["to_station"], "Jaipur")
        self.svc.delete("J0001")
        with self.assertRaises(NotFound):
            self.svc.get("J0001")
        self.assertEqual(self.svc.create(raw(passenger_name="Zed Ali"))["id"], "J0003")   # ids never reused

    def test_duplicate_journey_blocked(self):
        self.svc.create(raw())
        with self.assertRaises(ValidationError):
            self.svc.create(raw())

    def test_item_operations(self):
        self.svc.create(raw())
        j = self.svc.add_item("J0001", {"name": "camera", "essential": True})
        self.assertEqual(j["total_items"], 15)
        with self.assertRaises(ValidationError):
            self.svc.add_item("J0001", {"name": "CAMERA"})             # duplicate (case-insensitive)
        j = self.svc.update_item("J0001", "I1", {"packed": True})
        self.assertEqual(j["packed_items"], 1)
        j = self.svc.set_all_packed("J0001", True)
        self.assertEqual(j["completion"], 100.0)
        j = self.svc.set_all_packed("J0001", False)
        self.assertEqual(j["completion"], 0.0)
        j = self.svc.delete_item("J0001", "I15")
        self.assertEqual(j["total_items"], 14)
        with self.assertRaises(NotFound):
            self.svc.update_item("J0001", "I999", {"packed": True})
        with self.assertRaises(ValidationError):
            self.svc.update_item("J0001", "I1", {"quantity": "500"})

    def test_search_filter_sort(self):
        sample.load_into(self.svc)
        self.assertEqual(len(self.svc.journeys), 36)
        by_name = self.svc.query(q="Ananya")
        self.assertTrue(by_name and all("ananya" in j["passenger_name"].lower() for j in by_name))
        self.assertTrue(all(j["trip_status"] == "Past" for j in self.svc.query(status="past")))
        self.assertTrue(all(j["trip_status"] == "Today" for j in self.svc.query(status="today")))
        self.assertTrue(all(j["completion"] == 100 for j in self.svc.query(status="ready")))
        self.assertTrue(all(j["coach_class"] == "SL" for j in self.svc.query(coach="SL")))
        self.assertTrue(self.svc.query(q="camera"))                          # searches item names too
        self.assertEqual(self.svc.query(q="zzzz-nothing"), [])
        default = self.svc.query()
        self.assertGreaterEqual(default[0]["days_until"], 0)                 # upcoming trips come first
        self.assertTrue(default[-1]["days_until"] < 0)
        progress = [j["completion"] for j in self.svc.query(sort="progress")]
        self.assertEqual(progress, sorted(progress))

    def test_warnings(self):
        self.svc.create(raw(travel_date=TODAY.isoformat()))                                       # today, nothing packed
        self.svc.create(raw(passenger_name="Tom Dey", travel_date=(TODAY + timedelta(days=1)).isoformat()))
        self.svc.create(raw(passenger_name="Uma Das", travel_date=(TODAY + timedelta(days=3)).isoformat()))
        self.svc.create(raw(passenger_name="Vik Rao", travel_date=(TODAY + timedelta(days=30)).isoformat()))
        titles = [w["title"] for w in self.svc.warnings()]
        self.assertTrue(titles[0].startswith("Departing today"))
        self.assertTrue(any(t.startswith("Documents not packed, tomorrow") for t in titles))
        self.assertTrue(any(t.startswith("Packing is only 0% done, in 3 days") for t in titles))
        self.assertEqual(len(self.svc.warnings()), 3)                                             # day 30 gives no warning
        self.svc.set_all_packed("J0001", True)
        self.assertFalse([w for w in self.svc.warnings() if w["journey_id"] == "J0001"])

    def test_analytics(self):
        sample.load_into(self.svc)
        s = analytics.summarize(self.svc.journeys, TODAY)
        self.assertEqual(s["total_journeys"], 36)
        self.assertEqual(s["upcoming"] + s["today"] + s["past"], 36)
        self.assertEqual(s["total_items"], sum(len(j["items"]) for j in self.svc.journeys))
        self.assertEqual(sum(v["total"] for v in s["by_category"].values()), s["total_items"])
        empty = analytics.summarize([], TODAY)
        self.assertEqual((empty["total_journeys"], empty["overall_percent"], empty["avg_completion_live"]), (0, 0.0, None))


class StorageTests(unittest.TestCase):
    def test_round_trip_backup_and_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            svc = make_service(tmp)
            svc.create(raw())
            svc.create(raw(passenger_name="Ravi Kumar"))
            again = make_service(tmp)
            self.assertEqual(len(again.journeys), 2)
            self.assertTrue(Path(tmp, "journeys_backup.json").exists())
            with open(Path(tmp, "journeys.csv"), encoding="utf-8") as fh:
                rows = list(csv.DictReader(fh))
            self.assertEqual(len(rows), 2)
            self.assertIn("Train ticket", rows[0]["items"])

    def test_corrupted_file_recovers_from_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            svc = make_service(tmp)
            svc.create(raw())
            svc.create(raw(passenger_name="Ravi Kumar"))
            Path(tmp, "journeys.json").write_text("{ not json", encoding="utf-8")
            recovered = make_service(tmp)
            self.assertEqual(len(recovered.journeys), 1)                 # backup holds the previous save
            self.assertTrue(any("backup" in n for n in recovered.notes))
            self.assertTrue(list(Path(tmp).glob("journeys.corrupt_*.json")))

    def test_corrupted_without_backup_and_missing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "journeys.json").write_text("garbage", encoding="utf-8")
            svc = make_service(tmp)
            self.assertEqual(svc.journeys, [])
            self.assertTrue(svc.notes)
        with tempfile.TemporaryDirectory() as tmp:
            svc = make_service(tmp)                                       # nothing exists yet
            self.assertEqual(svc.journeys, [])
            self.assertTrue(Path(tmp, "journeys.json").exists())

    def test_bad_records_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            good = dict(raw(), id="J0001", passengers=2, items=[])
            Path(tmp, "journeys.json").write_text(json.dumps({"journeys": [good, {"id": "J0002"}, "junk"]}), encoding="utf-8")
            svc = make_service(tmp)
            self.assertEqual(len(svc.journeys), 1)
            self.assertTrue(any("Skipped 2" in n for n in svc.notes))


class ImportExportTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.tmp = Path(self._tmp.name)
        self.svc = make_service(self.tmp / "data")

    def test_import_good_and_bad_rows(self):
        result = importer.import_csv_text(sample.legacy_demo_csv(TODAY), self.svc, log_path=self.tmp / "log.txt")
        self.assertEqual(result["added"], 3)
        self.assertEqual(result["rejected"], 10)
        self.assertEqual(sorted(e["row"] for e in result["errors"]), list(range(4, 14)))
        self.assertIn("Row 4", (self.tmp / "log.txt").read_text())
        packed = [i["name"] for i in self.svc.journeys[0]["items"] if i["packed"]]
        self.assertEqual(packed, ["Train ticket", "ID proof"])               # 'name:packed' syntax works
        self.assertEqual(len(self.svc.journeys[1]["items"]), 14)             # blank items column -> default list

    def test_import_rejects_bad_files(self):
        for text in ("", "name,qty\nx,1\n"):
            with self.assertRaises(ValueError):
                importer.import_csv_text(text, self.svc, log_path=self.tmp / "log.txt")

    def test_export_csv_round_trips_through_import(self):
        sample.load_into(self.svc)
        name, ctype, body = reports.render("csv", self.svc, save_copy=False)
        other = make_service(self.tmp / "other")
        result = importer.import_csv_text(body, other, log_path=self.tmp / "log2.txt")
        self.assertEqual((result["added"], result["rejected"]), (36, 0))
        self.assertEqual(sum(len(j["items"]) for j in other.journeys), sum(len(j["items"]) for j in self.svc.journeys))

    def test_report_formats(self):
        sample.load_into(self.svc)
        for fmt, needle in (("md", "# Train Journey Checklist Report"), ("txt", "AUDIT LOG"), ("json", '"journeys"')):
            name, ctype, body = reports.render(fmt, self.svc, save_copy=True, out_dir=self.tmp / "reports")
            self.assertIn(needle, body)
            self.assertTrue((self.tmp / "reports" / name).exists())
        with self.assertRaises(KeyError):
            reports.render("pdf", self.svc)

    def test_sample_files_are_valid(self):
        count = sample.write_sample_files(self.tmp / "s", TODAY)
        self.assertEqual(count, 36)
        with open(self.tmp / "s" / "sample_journeys.csv", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 36)
        offsets = {(date.fromisoformat(r["travel_date"]) - TODAY).days for r in rows}
        self.assertTrue({0, 1, 2, 3, 7, 8} <= offsets)                       # boundary cases present


if __name__ == "__main__":
    unittest.main()
