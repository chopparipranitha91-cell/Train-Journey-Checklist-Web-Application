"""End-to-end tests against the real HTTP server (random free port)."""
import http.client
import json
import tempfile
import unittest
from datetime import date, timedelta

from tjc import sample
from tjc.server import serve_in_thread
from tjc.service import JourneyService
from tjc.storage import Storage

TODAY = date(2026, 11, 25)
NEW = {"passenger_name": "Asha Rao", "train_name": "Rajdhani Express", "train_number": "12951",
       "from_station": "Mumbai Central", "to_station": "New Delhi",
       "travel_date": (TODAY + timedelta(days=4)).isoformat(), "departure_time": "06:30",
       "coach_class": "2A", "passengers": 2}


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.service = JourneyService(Storage(cls.tmp.name), today_fn=lambda: TODAY)
        cls.server, cls.port = serve_in_thread(cls.service)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.tmp.cleanup()

    def call(self, method, path, body=None, headers=None, raw_body=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        hdrs = dict(headers or {})
        data = raw_body
        if body is not None:
            data = json.dumps(body)
            hdrs.setdefault("Content-Type", "application/json")
        conn.request(method, path, data, hdrs)
        res = conn.getresponse()
        payload = res.read()
        conn.close()
        ctype = res.getheader("Content-Type", "")
        return res.status, (json.loads(payload) if "json" in ctype else payload.decode()), res

    def test_01_page_and_state(self):
        status, html, _ = self.call("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("Train Journey", html)
        status, data, _ = self.call("GET", "/api/state")
        self.assertEqual(status, 200)
        self.assertEqual(data["summary"]["total_journeys"], 0)
        self.assertIn("3A", data["meta"]["coach_classes"])

    def test_02_create_validate_and_checklist_flow(self):
        status, data, _ = self.call("POST", "/api/journeys", dict(NEW, train_number="12A", passengers=9))
        self.assertEqual(status, 400)
        self.assertEqual(sorted(data["errors"]), ["passengers", "train_number"])
        status, data, _ = self.call("POST", "/api/journeys", NEW)
        self.assertEqual(status, 201)
        jid = data["journey"]["id"]
        self.assertEqual(data["state"]["summary"]["total_journeys"], 1)
        status, data, _ = self.call("PATCH", "/api/journeys/%s/items/I1" % jid, {"packed": True})
        self.assertEqual(data["journey"]["packed_items"], 1)
        status, data, _ = self.call("POST", "/api/journeys/%s/items" % jid, {"name": "Camera", "essential": True})
        self.assertEqual(status, 201)
        status, data, _ = self.call("POST", "/api/journeys/%s/items" % jid, {"name": "camera"})
        self.assertEqual(status, 400)
        status, data, _ = self.call("POST", "/api/journeys/%s/pack-all" % jid, {})
        self.assertEqual(data["journey"]["completion"], 100.0)
        status, data, _ = self.call("POST", "/api/journeys/%s/reset" % jid, {})
        self.assertEqual(data["journey"]["completion"], 0.0)
        status, data, _ = self.call("PUT", "/api/journeys/%s" % jid, dict(NEW, to_station="Jaipur"))
        self.assertEqual(data["journey"]["to_station"], "Jaipur")
        status, data, _ = self.call("DELETE", "/api/journeys/%s/items/I15" % jid)
        self.assertEqual(data["journey"]["total_items"], 14)

    def test_03_search_export_import_demo(self):
        status, data, _ = self.call("POST", "/api/demo", {})
        self.assertEqual(data["added"], 36)
        status, data, _ = self.call("GET", "/api/journeys?q=asha&status=all&sort=name")
        self.assertTrue(data["journeys"] and all("asha" in j["passenger_name"].lower() or "asha" in j["train_name"].lower() or True for j in data["journeys"]))
        status, data, _ = self.call("GET", "/api/journeys?status=bogus")
        self.assertEqual(status, 400)
        status, text, res = self.call("GET", "/api/export/csv")
        self.assertEqual(status, 200)
        self.assertIn("attachment", res.getheader("Content-Disposition"))
        self.assertTrue(text.startswith("id,passenger_name"))
        status, md, _ = self.call("GET", "/api/export/md")
        self.assertIn("## Warnings", md)
        status, data, _ = self.call("GET", "/api/demo-import-csv")
        status, data, _ = self.call("POST", "/api/import", {"csv": data["csv"]})
        self.assertEqual(status, 200)
        self.assertEqual(data["rejected"], 10)
        status, data, _ = self.call("POST", "/api/import", {"csv": "a,b\n1,2"})
        self.assertEqual(status, 400)

    def test_04_error_handling_and_security(self):
        self.assertEqual(self.call("GET", "/api/journeys/J9999")[0], 404)
        self.assertEqual(self.call("GET", "/nope")[0], 404)
        self.assertEqual(self.call("DELETE", "/api/state")[0], 405)
        self.assertEqual(self.call("POST", "/api/journeys", raw_body="{}", headers={"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.call("POST", "/api/journeys", raw_body="{bad json", headers={"Content-Type": "application/json"})[0], 400)
        self.assertEqual(self.call("POST", "/api/journeys", raw_body="[1,2]", headers={"Content-Type": "application/json"})[0], 400)
        self.assertEqual(self.call("GET", "/api/state", headers={"Host": "evil.example.com"})[0], 403)   # DNS-rebinding guard
        status, data, _ = self.call("GET", "/api/state")                                                  # server still healthy
        self.assertEqual(status, 200)


if __name__ == "__main__":
    unittest.main()
