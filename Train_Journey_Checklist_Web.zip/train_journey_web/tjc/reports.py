"""Report export: Markdown, plain-text audit log, CSV and JSON."""
import io
import json
from datetime import datetime
from pathlib import Path

from tjc import analytics, checklist
from tjc.storage import CSV_FIELDS, items_to_text
import csv

PROJECT_DIR = Path(__file__).resolve().parent.parent
REPORT_DIR = PROJECT_DIR / "reports"
FORMATS = {"md": ("text/markdown; charset=utf-8", "md"), "txt": ("text/plain; charset=utf-8", "txt"),
           "csv": ("text/csv; charset=utf-8", "csv"), "json": ("application/json; charset=utf-8", "json")}


def _rows(service):
    return sorted((checklist.decorate(j, service.today) for j in service.journeys),
                  key=lambda r: (r["travel_date"], r["departure_time"]))


def markdown(service):
    s = analytics.summarize(service.journeys, service.today)
    warns = service.warnings()
    lines = ["# Train Journey Checklist Report", "", "Generated for **%s**" % service.today, "",
             "## Summary", "", "| Metric | Value |", "|---|---|",
             "| Journeys | %d |" % s["total_journeys"], "| Upcoming | %d |" % s["upcoming"],
             "| Departing today | %d |" % s["today"], "| Past | %d |" % s["past"],
             "| Passengers | %d |" % s["total_passengers"],
             "| Items packed | %d of %d (%.1f%%) |" % (s["packed_items"], s["total_items"], s["overall_percent"]),
             "| Average packing, live trips | %s |" % ("n/a" if s["avg_completion_live"] is None else "%.1f%%" % s["avg_completion_live"]),
             "| Essential items missing | %d |" % s["essentials_missing"], "", "## Warnings", ""]
    lines += ["- **%s** - %s %s" % (w["level"].upper(), w["title"], w["message"]) for w in warns] or ["None."]
    lines += ["", "## Journeys", "",
              "| ID | Passenger | Train | Route | Date | Packed | Status |", "|---|---|---|---|---|---|---|"]
    for r in _rows(service):
        lines.append("| %s | %s | %s %s | %s -> %s | %s | %d/%d (%.0f%%) | %s |" % (
            r["id"], r["passenger_name"], r["train_number"], r["train_name"], r["from_station"],
            r["to_station"], r["travel_date"], r["packed_items"], r["total_items"], r["completion"], r["readiness"]))
    return "\n".join(lines) + "\n"


def text(service):
    s = analytics.summarize(service.journeys, service.today)
    lines = ["TRAIN JOURNEY CHECKLIST - AUDIT LOG", "Date: %s" % service.today, "=" * 72,
             "Journeys: %d   Upcoming: %d   Today: %d   Past: %d" % (s["total_journeys"], s["upcoming"], s["today"], s["past"]),
             "Items packed: %d / %d (%.1f%%)" % (s["packed_items"], s["total_items"], s["overall_percent"]),
             "Essential items missing on live trips: %d" % s["essentials_missing"], "", "WARNINGS"]
    lines += ["  [%s] %s" % (w["level"].upper(), w["title"]) for w in service.warnings()] or ["  none"]
    lines += ["", "-" * 72]
    for r in _rows(service):
        lines.append("%s  %s  %-18s %-14s -> %-14s %3d%%  %s" % (
            r["id"], r["travel_date"], r["passenger_name"][:18], r["from_station"][:14],
            r["to_station"][:14], r["completion"], r["readiness"]))
        if r["essentials_missing"] and r["trip_status"] != "Past":
            lines.append("        missing essentials: " + ", ".join(r["essentials_missing"]))
    return "\n".join(lines) + "\n"


def csv_text(service):
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_FIELDS, lineterminator="\n")
    writer.writeheader()
    for r in _rows(service):
        row = {k: r.get(k, "") for k in CSV_FIELDS}
        row["items"] = items_to_text(r["items"])
        writer.writerow(row)
    return buffer.getvalue()


def json_text(service):
    return json.dumps({"generated": str(service.today), "journeys": [dict(j) for j in service.journeys]}, indent=2)


def render(fmt, service, save_copy=True, out_dir=None):
    """Return (filename, content_type, text). A copy is also saved in reports/."""
    if fmt not in FORMATS:
        raise KeyError(fmt)
    body = {"md": markdown, "txt": text, "csv": csv_text, "json": json_text}[fmt](service)
    content_type, ext = FORMATS[fmt]
    name = "journey_report_%s.%s" % (datetime.now().strftime("%Y%m%d_%H%M%S"), ext)
    if save_copy:
        folder = Path(out_dir or REPORT_DIR)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / name).write_text(body, encoding="utf-8")
    return name, content_type, body
