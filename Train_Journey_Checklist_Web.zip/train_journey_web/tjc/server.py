"""Tiny local web server (standard library only): JSON API + the single-page GUI."""
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from tjc import analytics, importer, reports, sample
from tjc.service import NotFound, STATUS_FILTERS, SORTS
from tjc.validators import CATEGORIES, COACH_CLASSES, ValidationError

WEB_DIR = Path(__file__).resolve().parent.parent / "web"
MAX_BODY = 2 * 1024 * 1024


class HttpError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status, self.message, self.extra = status, message, extra or {}


def make_handler(service):
    routes = []

    def route(method, pattern):
        def register(func):
            routes.append((method, re.compile("^" + pattern + "$"), func))
            return func
        return register

    def state():
        return {"summary": analytics.summarize(service.journeys, service.today),
                "warnings": service.warnings(), "notes": service.notes,
                "meta": {"categories": CATEGORIES, "coach_classes": COACH_CLASSES, "statuses": STATUS_FILTERS,
                         "sorts": SORTS, "today": service.today.isoformat()}}

    @route("GET", r"/api/state")
    def get_state(h, m, body):
        return 200, state()

    @route("GET", r"/api/journeys")
    def list_journeys(h, m, body):
        q = h.query
        pick = lambda key, default: (q.get(key) or [default])[0]
        status, sort = pick("status", "all"), pick("sort", "date")
        if status not in STATUS_FILTERS or sort not in SORTS:
            raise HttpError(400, "Unknown status or sort.")
        return 200, {"journeys": service.query(pick("q", ""), status, pick("coach", "all"), sort)}

    @route("POST", r"/api/journeys")
    def create_journey(h, m, body):
        return 201, {"journey": service.create(body), "state": state()}

    @route("GET", r"/api/journeys/(J\d+)")
    def get_journey(h, m, body):
        return 200, {"journey": service.get(m.group(1))}

    @route("PUT", r"/api/journeys/(J\d+)")
    def update_journey(h, m, body):
        return 200, {"journey": service.update(m.group(1), body), "state": state()}

    @route("DELETE", r"/api/journeys/(J\d+)")
    def delete_journey(h, m, body):
        service.delete(m.group(1))
        return 200, {"state": state()}

    @route("POST", r"/api/journeys/(J\d+)/items")
    def add_item(h, m, body):
        return 201, {"journey": service.add_item(m.group(1), body), "state": state()}

    @route("PATCH", r"/api/journeys/(J\d+)/items/(I\d+)")
    def patch_item(h, m, body):
        return 200, {"journey": service.update_item(m.group(1), m.group(2), body), "state": state()}

    @route("DELETE", r"/api/journeys/(J\d+)/items/(I\d+)")
    def remove_item(h, m, body):
        return 200, {"journey": service.delete_item(m.group(1), m.group(2)), "state": state()}

    @route("POST", r"/api/journeys/(J\d+)/pack-all")
    def pack_all(h, m, body):
        return 200, {"journey": service.set_all_packed(m.group(1), True), "state": state()}

    @route("POST", r"/api/journeys/(J\d+)/reset")
    def reset_packing(h, m, body):
        return 200, {"journey": service.set_all_packed(m.group(1), False), "state": state()}

    @route("POST", r"/api/import")
    def import_csv(h, m, body):
        text = body.get("csv")
        if not isinstance(text, str):
            raise HttpError(400, "Send the CSV text in a 'csv' field.")
        try:
            result = importer.import_csv_text(text, service)
        except ValueError as exc:
            raise HttpError(400, str(exc))
        result["state"] = state()
        return 200, result

    @route("POST", r"/api/demo")
    def load_demo(h, m, body):
        return 200, {"added": sample.load_into(service), "state": state()}

    @route("GET", r"/api/demo-import-csv")
    def demo_csv(h, m, body):
        return 200, {"csv": sample.legacy_demo_csv(service.today)}

    @route("GET", r"/api/export/(md|txt|csv|json)")
    def export(h, m, body):
        name, content_type, text = reports.render(m.group(1), service)
        return "raw", (content_type, text.encode("utf-8"), name)

    class Handler(BaseHTTPRequestHandler):
        server_version = "TrainJourney/1.0"

        def log_message(self, fmt, *args):      # keep the terminal quiet
            pass

        def _send(self, status, payload, content_type="application/json; charset=utf-8", filename=None):
            data = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if filename:
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
            self.end_headers()
            self.wfile.write(data)

        def _host_ok(self):
            """Only answer requests addressed to localhost (blocks DNS-rebinding tricks)."""
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
            return host in ("127.0.0.1", "localhost", "::1")

        def _handle(self, method):
            parsed = urlparse(self.path)
            self.query = parse_qs(parsed.query)
            try:
                if not self._host_ok():
                    raise HttpError(403, "Forbidden host.")
                if method == "GET" and parsed.path in ("/", "/index.html"):
                    page = (WEB_DIR / "index.html").read_bytes()
                    return self._send(200, page, "text/html; charset=utf-8")
                body = {}
                if method in ("POST", "PUT", "PATCH"):
                    if "application/json" not in (self.headers.get("Content-Type") or ""):
                        raise HttpError(415, "Content-Type must be application/json.")
                    length = int(self.headers.get("Content-Length") or 0)
                    if length > MAX_BODY:
                        raise HttpError(413, "Request is too large.")
                    raw = self.rfile.read(length) if length else b"{}"
                    try:
                        body = json.loads(raw.decode("utf-8") or "{}")
                    except (ValueError, UnicodeDecodeError):
                        raise HttpError(400, "Request body is not valid JSON.")
                    if not isinstance(body, dict):
                        raise HttpError(400, "Request body must be a JSON object.")
                for verb, pattern, func in routes:
                    match = pattern.match(parsed.path)
                    if match and verb == method:
                        status, payload = func(self, match, body)
                        if status == "raw":
                            content_type, data, name = payload
                            return self._send(200, data, content_type, name)
                        return self._send(status, payload)
                if any(p.match(parsed.path) for _, p, _ in routes):
                    raise HttpError(405, "Method not allowed.")
                raise HttpError(404, "Not found.")
            except ValidationError as exc:
                self._send(400, {"error": "validation", "message": "Please fix the highlighted fields.",
                                 "errors": exc.errors})
            except NotFound:
                self._send(404, {"error": "not_found", "message": "That journey or item no longer exists."})
            except HttpError as exc:
                self._send(exc.status, dict({"error": "http", "message": exc.message}, **exc.extra))
            except Exception as exc:        # never crash the server on one bad request
                self._send(500, {"error": "server", "message": "Unexpected error: %s" % exc})

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

        def do_PUT(self):
            self._handle("PUT")

        def do_PATCH(self):
            self._handle("PATCH")

        def do_DELETE(self):
            self._handle("DELETE")

    return Handler


def create_server(service, host="127.0.0.1", port=8000):
    return ThreadingHTTPServer((host, port), make_handler(service))


def serve_in_thread(service, port=0):
    """Start on a free port in a background thread (used by tests). Returns (server, port)."""
    server = create_server(service, port=port)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1]
