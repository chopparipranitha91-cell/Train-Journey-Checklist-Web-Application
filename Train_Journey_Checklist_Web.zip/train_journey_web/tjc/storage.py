"""Local persistence: JSON store, CSV mirror, backup of the previous save, safe recovery."""
import csv
import json
import shutil
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
CSV_FIELDS = ["id", "passenger_name", "train_name", "train_number", "from_station", "to_station",
              "travel_date", "departure_time", "coach_class", "passengers", "notes",
              "total_items", "packed_items", "completion", "items"]
REQUIRED_KEYS = ["id", "passenger_name", "train_name", "train_number", "from_station", "to_station",
                 "travel_date", "departure_time", "coach_class", "passengers"]


def items_to_text(items):
    """'Train ticket:packed; Charger' - the same format the CSV importer reads."""
    return "; ".join(i["name"] + (":packed" if i.get("packed") else "") for i in items)


def check_journey(record):
    """Schema check for one stored journey. Raises ValueError if it is broken."""
    if not isinstance(record, dict):
        raise ValueError("journey must be an object")
    for key in REQUIRED_KEYS:
        if key not in record:
            raise ValueError("missing " + key)
    datetime.strptime(record["travel_date"], "%Y-%m-%d")
    items = record.get("items", [])
    if not isinstance(items, list):
        raise ValueError("items must be a list")
    clean_items = []
    for item in items:
        if not isinstance(item, dict) or "id" not in item or "name" not in item:
            raise ValueError("bad item")
        clean_items.append({"id": str(item["id"]), "name": str(item["name"]),
                            "category": str(item.get("category", "Other")),
                            "quantity": int(item.get("quantity", 1)),
                            "essential": bool(item.get("essential", False)),
                            "packed": bool(item.get("packed", False))})
    out = {k: record[k] for k in REQUIRED_KEYS}
    out["notes"] = str(record.get("notes", ""))
    out["items"] = clean_items
    return out


class Storage:
    def __init__(self, data_dir=None):
        self.data_dir = Path(data_dir) if data_dir else DATA_DIR
        self.json_path = self.data_dir / "journeys.json"
        self.csv_path = self.data_dir / "journeys.csv"
        self.backup_path = self.data_dir / "journeys_backup.json"

    def _read(self, path):
        data = json.loads(path.read_text(encoding="utf-8"))
        records = data["journeys"] if isinstance(data, dict) else data
        if not isinstance(records, list):
            raise ValueError("'journeys' must be a list")
        good, skipped = [], 0
        for record in records:
            try:
                good.append(check_journey(record))
            except (ValueError, KeyError, TypeError):
                skipped += 1
        return good, skipped

    def load(self):
        """Return (journeys, notes). Never crashes on a missing or corrupted file."""
        notes = []
        if not self.json_path.exists():
            self.save([])
            return [], []          # first run: a clean file was created, nothing to report
        try:
            journeys, skipped = self._read(self.json_path)
            if skipped:
                notes.append("Skipped %d unreadable journey record(s)." % skipped)
            return journeys, notes
        except (json.JSONDecodeError, ValueError, KeyError, OSError, UnicodeDecodeError):
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            kept = self.data_dir / ("journeys.corrupt_%s.json" % stamp)
            try:
                shutil.copyfile(self.json_path, kept)
                notes.append("Data file was unreadable; a copy was kept as %s." % kept.name)
            except OSError:
                notes.append("Data file was unreadable.")
            if self.backup_path.exists():
                try:
                    journeys, _ = self._read(self.backup_path)
                    notes.append("Recovered %d journey(s) from the backup file." % len(journeys))
                    return journeys, notes
                except (json.JSONDecodeError, ValueError, KeyError, OSError, UnicodeDecodeError):
                    pass
            notes.append("Started with an empty list.")
            return [], notes

    def save(self, journeys):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if self.json_path.exists():
            try:
                shutil.copyfile(self.json_path, self.backup_path)
            except OSError:
                pass
        temp = self.json_path.with_suffix(".tmp")
        temp.write_text(json.dumps({"version": 1, "journeys": journeys}, indent=2), encoding="utf-8")
        temp.replace(self.json_path)
        write_csv(self.csv_path, journeys)


def write_csv(path, journeys):
    from tjc.checklist import completion, packed_count
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for j in journeys:
            row = {k: j.get(k, "") for k in CSV_FIELDS}
            row.update(total_items=len(j["items"]), packed_items=packed_count(j["items"]),
                       completion=completion(j["items"]), items=items_to_text(j["items"]))
            writer.writerow(row)
