"""Core checklist logic: default packing list, progress and readiness maths."""
from datetime import date

# name, category, essential
DEFAULT_ITEMS = [
    ("Train ticket", "Documents", True), ("ID proof", "Documents", True),
    ("Mobile phone", "Electronics", True), ("Charger", "Electronics", False),
    ("Power bank", "Electronics", False), ("Headphones", "Electronics", False),
    ("Wallet", "Essentials", True), ("Cash", "Essentials", True),
    ("Water bottle", "Food", False), ("Snacks", "Food", False),
    ("Medicines", "Health", True), ("Clothes", "Clothing", False),
    ("Light blanket", "Clothing", False), ("Toiletries", "Personal care", False),
]
DEFAULTS_BY_NAME = {n.lower(): (c, e) for n, c, e in DEFAULT_ITEMS}


def make_item(item_id, name, category="Other", quantity=1, essential=False, packed=False):
    return {"id": item_id, "name": name, "category": category, "quantity": quantity,
            "essential": essential, "packed": packed}


def next_item_id(items):
    numbers = [int(i["id"][1:]) for i in items if str(i.get("id", ""))[1:].isdigit()]
    return "I%d" % (max(numbers, default=0) + 1)


def default_items():
    return [make_item("I%d" % n, name, cat, 1, essential)
            for n, (name, cat, essential) in enumerate(DEFAULT_ITEMS, 1)]


def packed_count(items):
    return sum(1 for i in items if i.get("packed"))


def completion(items):
    """Percentage of items packed (0 when the list is empty)."""
    return round(100.0 * packed_count(items) / len(items), 1) if items else 0.0


def essentials_missing(items):
    return [i["name"] for i in items if i.get("essential") and not i.get("packed")]


def readiness(items):
    pct = completion(items)
    if not items:
        return "Empty list"
    if pct == 100:
        return "Ready"
    if pct >= 75:
        return "Almost ready"
    if pct > 0:
        return "In progress"
    return "Not started"


def days_until(journey, today=None):
    today = today or date.today()
    return (date.fromisoformat(journey["travel_date"]) - today).days


def trip_status(journey, today=None):
    days = days_until(journey, today)
    return "Past" if days < 0 else "Today" if days == 0 else "Upcoming"


def decorate(journey, today=None):
    """Journey dict plus computed fields for the UI and reports."""
    items = journey.get("items", [])
    out = dict(journey)
    out.update({
        "total_items": len(items), "packed_items": packed_count(items),
        "completion": completion(items), "readiness": readiness(items),
        "essentials_missing": essentials_missing(items),
        "days_until": days_until(journey, today), "trip_status": trip_status(journey, today),
    })
    return out
