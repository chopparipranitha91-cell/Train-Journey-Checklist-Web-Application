"""Business logic: journeys, checklist items, search/filter and threshold warnings."""
import threading
from datetime import date

from tjc import checklist
from tjc.validators import (ValidationError, build_item_fields, build_journey_fields,
                            clean_bool, clean_category, clean_item_name, clean_quantity)

STATUS_FILTERS = ["all", "upcoming", "today", "past", "incomplete", "ready"]
SORTS = ["date", "date_desc", "progress", "name"]


def _locked(method):
    def wrapper(self, *args, **kwargs):
        with self.lock:
            return method(self, *args, **kwargs)
    wrapper.__name__ = method.__name__
    wrapper.__doc__ = method.__doc__
    return wrapper


class NotFound(KeyError):
    pass


class JourneyService:
    def __init__(self, storage, today_fn=date.today):
        self.storage = storage
        self.today_fn = today_fn
        self.lock = threading.RLock()
        self.journeys, self.notes = storage.load()

    @property
    def today(self):
        return self.today_fn()

    def _save(self):
        self.storage.save(self.journeys)

    # ---------- journeys ----------
    def _next_id(self):
        numbers = [int(j["id"][1:]) for j in self.journeys if j["id"][1:].isdigit()]
        return "J%04d" % (max(numbers, default=0) + 1)

    def _find(self, journey_id):
        wanted = str(journey_id).upper()
        for journey in self.journeys:
            if journey["id"].upper() == wanted:
                return journey
        raise NotFound(journey_id)

    def is_duplicate(self, fields, ignore_id=None):
        return any(j["passenger_name"].lower() == fields["passenger_name"].lower()
                   and j["train_number"] == fields["train_number"]
                   and j["travel_date"] == fields["travel_date"]
                   and j["id"] != ignore_id for j in self.journeys)

    @_locked
    def create(self, raw, items=None, save=True):
        fields = build_journey_fields(raw, self.today)
        if self.is_duplicate(fields):
            raise ValidationError({"passenger_name": "This passenger already has this train on this date."})
        journey = dict(id=self._next_id(), **fields)
        journey["items"] = items if items is not None else checklist.default_items()
        self.journeys.append(journey)
        if save:
            self._save()
        return checklist.decorate(journey, self.today)

    @_locked
    def update(self, journey_id, raw):
        journey = self._find(journey_id)
        fields = build_journey_fields(raw, self.today)
        if self.is_duplicate(fields, ignore_id=journey["id"]):
            raise ValidationError({"passenger_name": "This passenger already has this train on this date."})
        journey.update(fields)
        self._save()
        return checklist.decorate(journey, self.today)

    @_locked
    def delete(self, journey_id):
        self.journeys.remove(self._find(journey_id))
        self._save()

    @_locked
    def get(self, journey_id):
        return checklist.decorate(self._find(journey_id), self.today)

    # ---------- checklist items ----------
    def _find_item(self, journey, item_id):
        for item in journey["items"]:
            if item["id"] == item_id:
                return item
        raise NotFound(item_id)

    @_locked
    def add_item(self, journey_id, raw):
        journey = self._find(journey_id)
        fields = build_item_fields(raw)
        if any(i["name"].lower() == fields["name"].lower() for i in journey["items"]):
            raise ValidationError({"name": "This item is already on the list."})
        if len(journey["items"]) >= 60:
            raise ValidationError({"name": "A checklist can hold at most 60 items."})
        journey["items"].append(checklist.make_item(checklist.next_item_id(journey["items"]), **fields))
        self._save()
        return checklist.decorate(journey, self.today)

    @_locked
    def update_item(self, journey_id, item_id, patch):
        journey = self._find(journey_id)
        item = self._find_item(journey, item_id)
        errors, changes = {}, {}
        cleaners = {"packed": clean_bool, "essential": clean_bool, "quantity": clean_quantity,
                    "name": clean_item_name, "category": clean_category}
        for key, cleaner in cleaners.items():
            if key in patch:
                try:
                    changes[key] = cleaner(patch[key])
                except ValueError as exc:
                    errors[key] = str(exc)
        if "name" in changes and any(i is not item and i["name"].lower() == changes["name"].lower()
                                     for i in journey["items"]):
            errors["name"] = "This item is already on the list."
        if errors:
            raise ValidationError(errors)
        item.update(changes)
        self._save()
        return checklist.decorate(journey, self.today)

    @_locked
    def delete_item(self, journey_id, item_id):
        journey = self._find(journey_id)
        journey["items"].remove(self._find_item(journey, item_id))
        self._save()
        return checklist.decorate(journey, self.today)

    @_locked
    def set_all_packed(self, journey_id, packed):
        journey = self._find(journey_id)
        for item in journey["items"]:
            item["packed"] = bool(packed)
        self._save()
        return checklist.decorate(journey, self.today)

    # ---------- query & search ----------
    @_locked
    def query(self, q="", status="all", coach="all", sort="date"):
        today = self.today
        word = (q or "").strip().lower()
        rows = [checklist.decorate(j, today) for j in self.journeys]
        out = []
        for j in rows:
            if word:
                hay = " ".join([j["id"], j["passenger_name"], j["train_name"], j["train_number"],
                                j["from_station"], j["to_station"], j.get("notes", "")]
                               + [i["name"] for i in j["items"]]).lower()
                if word not in hay:
                    continue
            if coach not in ("all", "", None) and j["coach_class"] != coach:
                continue
            if status == "upcoming" and j["trip_status"] != "Upcoming":
                continue
            if status == "today" and j["trip_status"] != "Today":
                continue
            if status == "past" and j["trip_status"] != "Past":
                continue
            if status == "incomplete" and (j["trip_status"] == "Past" or j["completion"] >= 100):
                continue
            if status == "ready" and j["completion"] < 100:
                continue
            out.append(j)
        # default order: trips that have not left yet (soonest first), then past trips (most recent first)
        keys = {"date": lambda j: (j["days_until"] < 0, abs(j["days_until"]), j["departure_time"], j["id"]),
                "progress": lambda j: (j["completion"], j["travel_date"]),
                "name": lambda j: (j["passenger_name"].lower(), j["travel_date"])}
        if sort == "date_desc":
            out.sort(key=lambda j: (j["travel_date"], j["departure_time"], j["id"]), reverse=True)
        else:
            out.sort(key=keys.get(sort, keys["date"]))
        return out

    # ---------- threshold warnings ----------
    @_locked
    def warnings(self):
        """Warning flags for trips that are close and not packed. Most severe first."""
        found, past_unfinished = [], 0
        for j in (checklist.decorate(x, self.today) for x in self.journeys):
            days, pct, missing = j["days_until"], j["completion"], j["essentials_missing"]
            who = "%s (%s -> %s)" % (j["passenger_name"], j["from_station"], j["to_station"])
            if days < 0:
                past_unfinished += 1 if pct < 100 else 0
                continue
            docs = [i["name"] for i in j["items"] if i["category"] == "Documents"
                    and not i["packed"] and i["essential"]]
            if days == 0 and missing:
                found.append(("critical", j["id"], "Departing today: %d essential item(s) not packed" % len(missing),
                              "%s - still missing: %s." % (who, ", ".join(missing[:4]) + ("..." if len(missing) > 4 else ""))))
            elif days <= 2 and docs:
                found.append(("critical", j["id"], "Documents not packed, %s" % _in_days(days),
                              "%s - missing: %s." % (who, ", ".join(docs))))
            elif days <= 3 and pct < 50:
                found.append(("warning", j["id"], "Packing is only %d%% done, %s" % (pct, _in_days(days)),
                              "%s - %d of %d items packed." % (who, j["packed_items"], j["total_items"])))
            elif days <= 7 and pct == 0 and j["total_items"]:
                found.append(("info", j["id"], "Packing not started, %s" % _in_days(days), who + "."))
            if days <= 7 and not j["items"]:
                found.append(("warning", j["id"], "Empty checklist, %s" % _in_days(days), who + "."))
        if past_unfinished:
            found.append(("info", "", "%d past journey(s) still have unpacked items" % past_unfinished,
                          "Review or delete old journeys to keep the list tidy."))
        order = {"critical": 0, "warning": 1, "info": 2}
        found.sort(key=lambda w: (order[w[0]], w[1]))
        return [{"level": lv, "journey_id": jid, "title": title, "message": msg} for lv, jid, title, msg in found]


def _in_days(days):
    return "today" if days == 0 else "tomorrow" if days == 1 else "in %d days" % days
