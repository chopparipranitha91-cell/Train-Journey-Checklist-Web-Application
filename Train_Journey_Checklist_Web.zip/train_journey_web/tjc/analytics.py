"""Executive summary: totals, averages, status indicators and trends."""
from collections import Counter

from tjc import checklist
from tjc.validators import CATEGORIES


def summarize(journeys, today):
    rows = [checklist.decorate(j, today) for j in journeys]
    live = [r for r in rows if r["trip_status"] != "Past"]
    all_items = [i for j in journeys for i in j["items"]]

    by_category = {c: {"total": 0, "packed": 0} for c in CATEGORIES}
    for item in all_items:
        entry = by_category.setdefault(item["category"], {"total": 0, "packed": 0})
        entry["total"] += 1
        entry["packed"] += 1 if item["packed"] else 0

    months = Counter(r["travel_date"][:7] for r in rows)
    destinations = Counter(r["to_station"] for r in rows)
    classes = Counter(r["coach_class"] for r in rows)
    readiness = Counter(r["readiness"] for r in live)

    upcoming = sorted((r for r in live), key=lambda r: (r["travel_date"], r["departure_time"]))
    packed = len(checklist_packed(all_items))
    return {
        "total_journeys": len(rows),
        "upcoming": sum(1 for r in rows if r["trip_status"] == "Upcoming"),
        "today": sum(1 for r in rows if r["trip_status"] == "Today"),
        "past": sum(1 for r in rows if r["trip_status"] == "Past"),
        "total_passengers": sum(r["passengers"] for r in rows),
        "total_items": len(all_items),
        "packed_items": packed,
        "overall_percent": round(100.0 * packed / len(all_items), 1) if all_items else 0.0,
        "avg_completion_live": round(sum(r["completion"] for r in live) / len(live), 1) if live else None,
        "essentials_missing": sum(len(r["essentials_missing"]) for r in live),
        "ready_trips": sum(1 for r in live if r["completion"] == 100),
        "readiness": {k: readiness.get(k, 0) for k in
                      ("Ready", "Almost ready", "In progress", "Not started", "Empty list")},
        "by_category": by_category,
        "by_month": sorted(months.items()),
        "top_destinations": destinations.most_common(5),
        "by_class": dict(classes),
        "next_trips": [{"id": r["id"], "passenger_name": r["passenger_name"], "train_name": r["train_name"],
                        "from_station": r["from_station"], "to_station": r["to_station"],
                        "travel_date": r["travel_date"], "days_until": r["days_until"],
                        "completion": r["completion"]} for r in upcoming[:5]],
    }


def checklist_packed(items):
    return [i for i in items if i.get("packed")]
