"""Train Journey Checklist - starts the local web app and opens it in your browser.

    py main.py            (or: python main.py)
    py main.py --port 8080 --no-browser
"""
import argparse
import threading
import webbrowser

from tjc.server import create_server
from tjc.service import JourneyService
from tjc.storage import Storage


def main():
    parser = argparse.ArgumentParser(description="Train Journey Checklist")
    parser.add_argument("--port", type=int, default=8000, help="port to listen on (default 8000)")
    parser.add_argument("--no-browser", action="store_true", help="do not open the browser automatically")
    args = parser.parse_args()

    service = JourneyService(Storage())
    try:
        server = create_server(service, port=args.port)
    except OSError:
        print("Port %d is busy. Try: py main.py --port %d" % (args.port, args.port + 1))
        return
    url = "http://127.0.0.1:%d" % args.port
    for note in service.notes:
        print("Note:", note)
    print("Train Journey Checklist is running at", url)
    print("Press Ctrl+C in this terminal to stop (your data is saved after every change).")
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped. Bye!")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
