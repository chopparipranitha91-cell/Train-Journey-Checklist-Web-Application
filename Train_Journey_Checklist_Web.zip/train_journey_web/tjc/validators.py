"""Defensive input validation shared by the web API and the CSV importer.

Every `clean_*` function returns a clean value or raises ValueError with a
friendly message. `build_*` functions validate a whole record and raise
ValidationError with one message per bad field.
"""
import re
import string
from datetime import date, datetime, timedelta

CATEGORIES = ["Documents", "Electronics", "Essentials", "Food", "Health",
              "Clothing", "Personal care", "Other"]
COACH_CLASSES = {"SL": "Sleeper", "3A": "AC 3 Tier", "2A": "AC 2 Tier",
                 "1A": "AC First Class", "CC": "Chair Car", "2S": "Second Sitting"}
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y")


class ValidationError(ValueError):
    """Carries a dict of {field: message}."""

    def __init__(self, errors):
        self.errors = dict(errors)
        super().__init__("; ".join("%s: %s" % kv for kv in self.errors.items()))


def _text(value):
    return " ".join(str(value if value is not None else "").split())


def clean_person(value):
    text = _text(value)
    if not 2 <= len(text) <= 40:
        raise ValueError("Name must be 2 to 40 characters.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z .'\-]*", text):
        raise ValueError("Use letters, spaces and . ' - only.")
    return string.capwords(text)


def clean_train_name(value):
    text = _text(value)
    if not 2 <= len(text) <= 40:
        raise ValueError("Train name must be 2 to 40 characters.")
    if not re.fullmatch(r"[A-Za-z0-9 &.'\-]+", text) or not re.search(r"[A-Za-z]", text):
        raise ValueError("Use letters, digits, spaces and & . ' - only.")
    return string.capwords(text)


def clean_train_number(value):
    text = _text(value)
    if not re.fullmatch(r"\d{5}", text):
        raise ValueError("Train number must be exactly 5 digits, e.g. 12951.")
    return text


def clean_station(value):
    text = _text(value)
    if not 2 <= len(text) <= 40:
        raise ValueError("Station must be 2 to 40 characters.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z .'()\-]*", text):
        raise ValueError("Use letters, spaces and . ' ( ) - only.")
    return string.capwords(text)


def parse_date(value):
    text = _text(value)
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    raise ValueError("Date must be a real day like 2026-12-31 or 31-12-2026.")


def clean_time(value):
    text = _text(value)
    if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", text):
        raise ValueError("Time must be 24-hour HH:MM, e.g. 06:45.")
    return text


def clean_coach(value):
    text = _text(value).upper()
    if text not in COACH_CLASSES:
        raise ValueError("Class must be one of: " + ", ".join(COACH_CLASSES))
    return text


def clean_passengers(value):
    try:
        number = int(str(value).strip())
    except ValueError:
        raise ValueError("Passengers must be a whole number.")
    if not 1 <= number <= 6:
        raise ValueError("Passengers must be between 1 and 6.")
    return number


def clean_notes(value):
    text = _text(value)
    if len(text) > 200:
        raise ValueError("Notes can be at most 200 characters.")
    return text


def clean_item_name(value):
    text = _text(value)
    if not 2 <= len(text) <= 40:
        raise ValueError("Item name must be 2 to 40 characters.")
    if not re.fullmatch(r"[A-Za-z0-9 .,'&()/\-]+", text) or not re.search(r"[A-Za-z]", text):
        raise ValueError("Use letters, digits, spaces and . , ' & ( ) / - only.")
    return text[0].upper() + text[1:]


def clean_category(value):
    text = _text(value).lower() or "other"
    for category in CATEGORIES:
        if category.lower() == text:
            return category
    raise ValueError("Category must be one of: " + ", ".join(CATEGORIES))


def clean_quantity(value):
    try:
        number = int(str(value).strip())
    except ValueError:
        raise ValueError("Quantity must be a whole number.")
    if not 1 <= number <= 99:
        raise ValueError("Quantity must be between 1 and 99.")
    return number


def clean_bool(value):
    if isinstance(value, bool):
        return value
    text = _text(value).lower()
    if text in ("true", "1", "yes", "y", "packed"):
        return True
    if text in ("false", "0", "no", "n", ""):
        return False
    raise ValueError("Must be true or false.")


def _run(steps, raw):
    out, errors = {}, {}
    for key, cleaner, required in steps:
        value = raw.get(key)
        if value is None or _text(value) == "":
            if required:
                errors[key] = "This field is required."
            continue                      # optional and blank: leave it out, callers set defaults
        try:
            out[key] = cleaner(value)
        except ValueError as exc:
            errors[key] = str(exc)
    return out, errors


def build_journey_fields(raw, today=None):
    """Validate a journey record. Returns clean fields (dates as ISO strings)."""
    today = today or date.today()
    steps = [
        ("passenger_name", clean_person, True), ("train_name", clean_train_name, True),
        ("train_number", clean_train_number, True), ("from_station", clean_station, True),
        ("to_station", clean_station, True), ("travel_date", parse_date, True),
        ("departure_time", clean_time, True), ("coach_class", clean_coach, True),
        ("passengers", clean_passengers, True), ("notes", clean_notes, False),
    ]
    out, errors = _run(steps, raw)
    if "from_station" in out and "to_station" in out and out["from_station"].lower() == out["to_station"].lower():
        errors["to_station"] = "Destination must be different from the starting station."
    if "travel_date" in out:
        day = out["travel_date"]
        if day < today - timedelta(days=365):
            errors["travel_date"] = "Travel date is more than a year in the past."
        elif day > today + timedelta(days=365):
            errors["travel_date"] = "Travel date is more than a year ahead."
    if errors:
        raise ValidationError(errors)
    out["travel_date"] = out["travel_date"].isoformat()
    out.setdefault("notes", "")
    return out


def build_item_fields(raw):
    steps = [("name", clean_item_name, True), ("category", clean_category, False),
             ("quantity", clean_quantity, False), ("essential", clean_bool, False)]
    out, errors = _run([(k, c, r) for k, c, r in steps], raw)
    if errors:
        raise ValidationError(errors)
    out.setdefault("category", "Other")
    out.setdefault("quantity", 1)
    out["essential"] = bool(out.get("essential", False))
    return out
