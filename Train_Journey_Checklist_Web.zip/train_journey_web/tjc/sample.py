"""Realistic sample data. Dates are relative to *today*, so the demo always has trips
departing today, tomorrow, in 2-3 days, next week and so on, plus past trips.

`python -m tjc.sample` rewrites the static files in the data folder.
"""
import csv
import io
import json
import random
from datetime import date, timedelta
from pathlib import Path

from tjc import checklist
from tjc.storage import CSV_FIELDS, items_to_text

NAMES = ["Aarav Sharma", "Ananya Reddy", "Rahul Kumar", "Priya Nair", "Vikram Singh", "Sneha Rao",
         "Arjun Patel", "Meera Iyer", "Kiran Das", "Sana Khan", "Rohit Verma", "Divya Menon",
         "Nikhil Joshi", "Pooja Gupta", "Aditya Rao", "Lakshmi Devi", "Manish Yadav", "Ishita Bose",
         "Varun Chawla", "Neha Sethi", "Suresh Babu", "Riya Kapoor", "Abhishek Jain", "Swathi Krishna",
         "Mohan Lal", "Keerthi Reddy", "Tarun Gupta", "Harini Subramanian", "Sai Charan", "Deepak Mehta",
         "Akhila Prasad", "Gautam Roy", "Nandini Rao", "Prakash Kumar", "Zoya Ali", "Imran Sheikh"]

# train name, number, from, to, class
TRAINS = [
    ("Rajdhani Express", "12951", "Mumbai Central", "New Delhi", "2A"),
    ("Shatabdi Express", "12009", "Mumbai Central", "Ahmedabad", "CC"),
    ("Vande Bharat Express", "20701", "Secunderabad", "Visakhapatnam", "CC"),
    ("Duronto Express", "12269", "Chennai Central", "Hazrat Nizamuddin", "3A"),
    ("Garib Rath", "12203", "Saharsa", "Amritsar", "3A"),
    ("Godavari Express", "12727", "Hyderabad", "Visakhapatnam", "SL"),
    ("Charminar Express", "12760", "Chennai Central", "Hyderabad", "SL"),
    ("Karnataka Express", "12627", "Bengaluru", "New Delhi", "3A"),
    ("Howrah Mail", "12809", "Mumbai Cst", "Howrah", "SL"),
    ("Coromandel Express", "12841", "Howrah", "Chennai Central", "2A"),
    ("Jan Shatabdi", "12076", "Thiruvananthapuram", "Kozhikode", "2S"),
    ("Tejas Express", "22119", "Mumbai Cst", "Karmali", "CC"),
    ("Konkan Kanya", "10111", "Mumbai Cst", "Madgaon", "SL"),
    ("Ganga Sutlej Express", "13307", "Dhanbad", "Firozpur", "SL"),
]

# days from today until departure: covers the boundary cases 0, 1, 2, 3, 7, 8
OFFSETS = [-30, -21, -14, -9, -6, -4, -2, -1, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 7, 8, 9, 10,
           12, 14, 16, 20, 25, 30, 38, 45, 60, 75, 90]
TIMES = ["05:45", "06:10", "06:40", "08:15", "10:30", "12:05", "14:20", "16:45", "18:30", "20:15", "22:00", "23:10"]


def _packed_probability(offset):
    if offset < 0:
        return 0.95
    if offset == 0:
        return 0.8
    if offset <= 3:
        return 0.6
    if offset <= 7:
        return 0.4
    if offset <= 20:
        return 0.2
    return 0.05


def sample_raw_rows(today=None):
    """Raw string rows (what a CSV would contain) with a deterministic packing state."""
    today = today or date.today()
    rng = random.Random(58)
    rows = []
    for number, offset in enumerate(OFFSETS):
        train = TRAINS[number % len(TRAINS)]
        items = checklist.default_items()
        for item in items:
            item["packed"] = rng.random() < _packed_probability(offset)
        if number % 9 == 4:                                 # a few extra items
            items.append(checklist.make_item("I15", "Camera", "Electronics", 1, False, rng.random() < 0.5))
        if number == 11:                                    # edge case: nothing packed yet
            for item in items:
                item["packed"] = False
        if number == 14:                                    # edge case: everything packed
            for item in items:
                item["packed"] = True
        rows.append({
            "passenger_name": NAMES[number % len(NAMES)], "train_name": train[0], "train_number": train[1],
            "from_station": train[2], "to_station": train[3],
            "travel_date": (today + timedelta(days=offset)).isoformat(),
            "departure_time": TIMES[number % len(TIMES)], "coach_class": train[4],
            "passengers": str(1 + number % 4), "notes": "", "items": items})
    return rows


def load_into(service, today=None):
    """Add the sample journeys (skipping duplicates). Returns how many were added."""
    from tjc.validators import ValidationError
    added = 0
    for row in sample_raw_rows(today or service.today):
        items = row.pop("items")
        try:
            service.create(row, items=items, save=False)
            added += 1
        except ValidationError:
            pass
    if added:
        service._save()
    return added


def legacy_demo_csv(today=None):
    """A small CSV with deliberate mistakes - used to demonstrate the import error log."""
    today = today or date.today()
    d = lambda off: (today + timedelta(days=off)).isoformat()
    good = dict(train_name="Vande Bharat Express", train_number="20701", from_station="Secunderabad",
                to_station="Visakhapatnam", departure_time="06:00", coach_class="CC", passengers="2")
    rows = [
        dict(good, passenger_name="Kavya Menon", travel_date=d(5), items="Train ticket:packed; ID proof:packed; Charger"),
        dict(good, passenger_name="Rahul Verma", travel_date=d(9), coach_class="3A", items=""),
        dict(good, passenger_name="", travel_date=d(4), items=""),
        dict(good, passenger_name="Bad Number", train_number="12A", travel_date=d(4), items=""),
        dict(good, passenger_name="Bad Date", travel_date="31-02-%d" % (today.year + 1), items=""),
        dict(good, passenger_name="Bad Time", travel_date=d(6), departure_time="25:99", items=""),
        dict(good, passenger_name="Bad Class", travel_date=d(6), coach_class="XX", items=""),
        dict(good, passenger_name="Too Many", travel_date=d(6), passengers="9", items=""),
        dict(good, passenger_name="Same Station", travel_date=d(6), to_station="Secunderabad", items=""),
        dict(good, passenger_name="Too Old", travel_date=d(-500), items=""),
        dict(good, passenger_name="Kavya Menon", travel_date=d(5), items=""),                 # duplicate of row 2
        dict(good, passenger_name="Bad Item", travel_date=d(8), items="Phone;;X;"),
        dict(good, passenger_name="Meena Iyer", travel_date=d(12), from_station="Chennai Central",
             to_station="Bengaluru", train_name="Shatabdi Express", train_number="12007", items="Train ticket; Snacks:packed"),
    ]
    columns = ["passenger_name", "train_name", "train_number", "from_station", "to_station", "travel_date",
               "departure_time", "coach_class", "passengers", "items"]
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows({c: r.get(c, "") for c in columns} for r in rows)
    return buffer.getvalue()


def write_sample_files(data_dir, today=None):
    today = today or date.today()
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    rows = sample_raw_rows(today)
    journeys = []
    for number, row in enumerate(rows, 1):
        journey = {k: v for k, v in row.items()}
        journey["id"] = "J%04d" % number
        journey["passengers"] = int(journey["passengers"])
        journeys.append(journey)
    (data_dir / "sample_journeys.json").write_text(json.dumps({"version": 1, "journeys": journeys}, indent=2), encoding="utf-8")
    with open(data_dir / "sample_journeys.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, lineterminator="\n")
        writer.writeheader()
        for j in journeys:
            row = {k: j.get(k, "") for k in CSV_FIELDS}
            row.update(total_items=len(j["items"]), packed_items=checklist.packed_count(j["items"]),
                       completion=checklist.completion(j["items"]), items=items_to_text(j["items"]))
            writer.writerow(row)
    (data_dir / "legacy_import_demo.csv").write_text(legacy_demo_csv(today), encoding="utf-8")
    return len(journeys)


if __name__ == "__main__":
    folder = Path(__file__).resolve().parent.parent / "data"
    print("Wrote %d sample journeys to %s" % (write_sample_files(folder), folder))
