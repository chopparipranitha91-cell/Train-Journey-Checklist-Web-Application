# Train Journey Checklist (Project #58)

Plan train trips and track whether your essential items are packed. It is a local web app with a modern
single-page GUI, built with **only the Python standard library**. There is nothing to install and it works offline.

## Run it (VS Code)
1. Extract the ZIP, then use **File > Open Folder** and select the folder that contains `main.py`.
2. Open **Terminal > New Terminal** and run `py main.py` (or `python main.py`).
3. Your browser opens at http://127.0.0.1:8000. If it does not, open that address yourself.
4. On the first run click **Load demo data** to see every screen filled in.
5. Press `Ctrl+C` in the terminal to stop. Your data is saved after every change.

Options: `py main.py --port 8080` (if port 8000 is busy), `py main.py --no-browser`.
Run the tests with `py -m unittest discover -s tests -v` (27 tests).

## What you get
| Screen | Features |
|---|---|
| Dashboard | Next-departure banner, KPI cards, overall packing ring, alert list, next trips with progress bars, packing by category, journeys per month, readiness and top destinations |
| Journeys | Live search (passenger, train, station, or even an item name like "charger"), filters (upcoming, today, past, not fully packed, fully packed, class), sorting, progress card per trip |
| Journey detail | Checklist grouped by category with one-click tick boxes, essential markers, add/remove items, mark all packed, reset, edit and delete journey |
| Import & Export | CSV bulk import with a row-by-row error table, export to Markdown, text audit log, CSV and JSON, demo-data loader |

Brief checklist: menu-driven UI (the GUI replaces the terminal menu), defensive validation, core packing logic,
JSON + CSV persistence, search and filter, executive summary, multi-format export, threshold warnings, bulk CSV import with error log, GUI, 36 sample records.

## Alerts (threshold warnings)
| Rule | Level |
|---|---|
| Departing today with essential items unpacked | critical |
| Ticket or ID (essential documents) unpacked, trip is within 2 days | critical |
| Trip within 3 days and less than 50% packed, or an empty checklist within 7 days | warning |
| Nothing packed yet and the trip is within 7 days | info |
| Past journeys still holding unpacked items | info |

## Validation rules
- Passenger: 2-40 letters. Train name: 2-40 characters. Train number: exactly 5 digits.
- Stations: 2-40 letters, and the destination must differ from the start. Time: 24-hour `HH:MM`.
- Class: SL, 3A, 2A, 1A, CC or 2S. Passengers: 1-6. Date: a real day, from 1 year back to 1 year ahead.
- Dates accept `YYYY-MM-DD`, `DD-MM-YYYY` and `DD/MM/YYYY`. A passenger cannot have the same train on the same date twice.
- Items: name 2-40 characters, quantity 1-99, at most 60 items per checklist, no duplicate names.
- Errors appear next to the field. The server re-checks everything, so the API cannot be fooled either.

## CSV import format
Required columns: `passenger_name, train_name, train_number, from_station, to_station, travel_date, departure_time, coach_class, passengers`.
Optional: `notes`, `items` such as `Train ticket:packed; ID proof:packed; Charger`. A blank `items` cell gets the standard 14-item list.
Rejected rows are shown in the GUI and logged in `logs/import_errors.txt`. The exported CSV can be imported again.
`data/legacy_import_demo.csv` is a deliberately messy file (3 good rows, 10 bad ones) for demos.

## Data files
- `data/journeys.json` is the main store. `data/journeys.csv` is a readable mirror, and `data/journeys_backup.json` holds the previous save.
- A missing file is recreated. A corrupted file is copied aside as `journeys.corrupt_<time>.json`, and the app recovers from the backup when it can.
- `data/sample_journeys.json/.csv` are the 36 sample records. Their dates are relative to the day they were generated; the **Load demo data** button always uses today's date.
- Exported reports are also saved in `reports/`.

## Build plan (how this was built, and how to extend it)
| Step | What | Where |
|---|---|---|
| 1 | Project skeleton, no external packages | `main.py`, `tjc/`, `web/`, `tests/`, `data/` |
| 2 | Data model: a journey with a list of checklist items | `tjc/checklist.py`, `tjc/storage.py` |
| 3 | Validation, one cleaner per field, shared by the GUI and the importer | `tjc/validators.py` |
| 4 | Core logic: CRUD, packing progress, essentials, search/filter/sort, warnings | `tjc/service.py` |
| 5 | Persistence with backup, atomic write and corruption recovery | `tjc/storage.py` |
| 6 | Summary metrics and trends | `tjc/analytics.py` |
| 7 | CSV import with error log, report export | `tjc/importer.py`, `tjc/reports.py` |
| 8 | Sample data generator (boundary cases: 0, 1, 2, 3, 7, 8 days) | `tjc/sample.py` |
| 9 | Local JSON API (localhost only, host-header check, JSON-only writes) | `tjc/server.py` |
| 10 | Single-page GUI with no external files or CDNs | `web/index.html` |
| 11 | Tests: 27 unit and end-to-end API tests, plus a browser walkthrough | `tests/` |

Ideas to extend: user-defined checklist templates per trip type, PNR field, reminders, printable checklist view, Streamlit front end on the same `tjc.service`.

## Suggested demo (about 3 minutes)
1. Launch with `py main.py`, then click **Load demo data** on the dashboard.
2. Show the alerts and the packing ring, then open a trip departing today.
3. Tick off the missing essentials and watch the percentage and the alert update.
4. **+ New journey** with bad input (train number `12A`, passengers `9`, same From and To) to show the inline validation.
5. **Import & Export**, then **Fill with messy demo file**, then **Import CSV** to show the error table. Export a report.
6. Stop the app with `Ctrl+C`, run it again and show that everything is still there.
