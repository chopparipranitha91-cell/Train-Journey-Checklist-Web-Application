"""Bulk CSV import with row-by-row validation and an error log."""
import csv
import io
from datetime import datetime
from pathlib import Path

from tjc import checklist
from tjc.validators import ValidationError, clean_category, clean_item_name

PROJECT_DIR = Path(__file__).resolve().parent.parent
LOG_PATH = PROJECT_DIR / "logs" / "import_errors.txt"
REQUIRED = ["passenger_name", "train_name", "train_number", "from_station", "to_station",
            "travel_date", "departure_time", "coach_class", "passengers"]
MAX_ROWS = 500


def parse_items(text):
    """'Train ticket:packed; Charger; Blanket' -> list of checklist items."""
    items = []
    for number, part in enumerate([p for p in (text or "").split(";") if p.strip()], 1):
        name_part, _, flag = part.strip().partition(":")
        name = clean_item_name(name_part)
        category, essential = checklist.DEFAULTS_BY_NAME.get(name.lower(), ("Other", False))
        if any(i["name"].lower() == name.lower() for i in items):
            raise ValueError("items: '%s' is listed twice" % name)
        items.append(checklist.make_item("I%d" % number, name, clean_category(category), 1,
                                         essential, flag.strip().lower() == "packed"))
    return items


def import_csv_text(text, service, log_path=None):
    """Add valid rows to `service`; return {'added', 'rejected', 'errors': [{row, message}]}.

    Raises ValueError for empty files, unreadable files or missing columns."""
    if not text.strip():
        raise ValueError("The CSV is empty.")
    reader = csv.DictReader(io.StringIO(text.lstrip("﻿")))
    headers = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
    missing = [c for c in REQUIRED if c not in headers]
    if missing:
        raise ValueError("CSV is missing required column(s): " + ", ".join(missing))
    added, errors = 0, []
    for number, row in enumerate(reader, start=2):          # row 1 is the header
        if number - 1 > MAX_ROWS:
            errors.append({"row": number, "message": "Stopped: more than %d rows." % MAX_ROWS})
            break
        clean = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items() if k}
        try:
            try:
                items = parse_items(clean.get("items", "")) if clean.get("items") else None
            except ValueError as exc:
                raise ValueError("items: %s" % str(exc).removeprefix("items: "))
            service.create(clean, items=items, save=False)
            added += 1
        except ValidationError as exc:
            errors.append({"row": number, "message": "; ".join("%s: %s" % kv for kv in exc.errors.items())})
        except ValueError as exc:
            errors.append({"row": number, "message": str(exc)})
    if added:
        service._save()
    _write_log(added, errors, log_path)
    return {"added": added, "rejected": len(errors), "errors": errors}


def _write_log(added, errors, log_path=None):
    path = Path(log_path or LOG_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["Import at %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             "Added: %d   Rejected: %d" % (added, len(errors)), ""]
    lines += ["Row %d: %s" % (e["row"], e["message"]) for e in errors]
    with open(path, "a", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n\n")
